import { createContext, useContext, useState } from 'react';
import { employees as initialEmployees } from '../data/employees';

const EmployeesContext = createContext(null);

export function EmployeesProvider({ children }) {
  // الموظفين أصلاً عندهم id (زي E001) فبنستخدمه لو موجود، ولو حد جديد اتضاف من غيره بنولّد واحد
  const [employees, setEmployees] = useState(
    initialEmployees.map((e, i) => ({ id: e.id || `E${i + 1}`, ...e }))
  );

  function addEmployee(data) {
    setEmployees((prev) => [...prev, { id: `E${Date.now()}`, ...data }]);
  }

  function updateEmployee(id, data) {
    setEmployees((prev) => prev.map((e) => (e.id === id ? { ...e, ...data } : e)));
  }

  function deleteEmployee(id) {
    setEmployees((prev) => prev.filter((e) => e.id !== id));
  }

  const value = { employees, addEmployee, updateEmployee, deleteEmployee };
  return <EmployeesContext.Provider value={value}>{children}</EmployeesContext.Provider>;
}

export function useEmployees() {
  return useContext(EmployeesContext);
}
