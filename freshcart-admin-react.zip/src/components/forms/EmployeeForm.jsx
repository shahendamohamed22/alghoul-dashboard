import { useState, useEffect } from 'react';
import { useBranches } from '../../context/BranchesContext';

const emptyForm = { name: '', branch: '', role: '', start: '', end: '', status: 'Active', phone: '' };

export default function EmployeeForm({ initialData, onSubmit, onCancel, submitLabel }) {
  const { branches } = useBranches();
  const [form, setForm] = useState(emptyForm);

  useEffect(() => {
    setForm(initialData ? { ...emptyForm, ...initialData } : emptyForm);
  }, [initialData]);

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  function handleSubmit(e) {
    e.preventDefault();
    onSubmit(form);
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="modal-body pt-0">
        <div className="mb-3">
          <label className="form-label small">Employee Name *</label>
          <input className="form-control" name="name" placeholder="e.g. Alice Cooper" value={form.name} onChange={handleChange} required />
        </div>
        <div className="row">
          <div className="col-6 mb-3">
            <label className="form-label small">Branch</label>
            <select className="form-select" name="branch" value={form.branch} onChange={handleChange}>
              <option value="">-- اختاري فرع --</option>
              {branches.map((b) => <option key={b.id} value={b.name}>{b.name}</option>)}
            </select>
          </div>
          <div className="col-6 mb-3">
            <label className="form-label small">Role *</label>
            <input className="form-control" name="role" placeholder="e.g. Cashier" value={form.role} onChange={handleChange} required />
          </div>
        </div>
        <div className="row">
          <div className="col-6 mb-3">
            <label className="form-label small">Work Start</label>
            <input type="time" className="form-control" name="start" value={form.start} onChange={handleChange} />
          </div>
          <div className="col-6 mb-3">
            <label className="form-label small">Work End</label>
            <input type="time" className="form-control" name="end" value={form.end} onChange={handleChange} />
          </div>
        </div>
        <div className="row">
          <div className="col-6 mb-3">
            <label className="form-label small">Status</label>
            <select className="form-select" name="status" value={form.status} onChange={handleChange}>
              <option value="Active">Active</option>
              <option value="On Leave">On Leave</option>
            </select>
          </div>
          <div className="col-6 mb-3">
            <label className="form-label small">Phone</label>
            <input className="form-control" name="phone" placeholder="(555) 123-4567" value={form.phone} onChange={handleChange} />
          </div>
        </div>
      </div>
      <div className="modal-footer border-0">
        <button type="button" className="btn btn-outline-secondary" onClick={onCancel}>Cancel</button>
        <button type="submit" className="btn bg-brand-dark text-white">{submitLabel}</button>
      </div>
    </form>
  );
}
