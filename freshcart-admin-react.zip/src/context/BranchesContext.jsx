import { createContext, useContext, useState } from 'react';
import { branches as initialBranches } from '../data/branches';

const BranchesContext = createContext(null);

export function BranchesProvider({ children }) {
  const [branches, setBranches] = useState(
    initialBranches.map((b, i) => ({ id: i + 1, ...b }))
  );

  function addBranch(data) {
    setBranches((prev) => [...prev, { id: Date.now(), ...data }]);
  }

  function updateBranch(id, data) {
    setBranches((prev) => prev.map((b) => (b.id === id ? { ...b, ...data } : b)));
  }

  function deleteBranch(id) {
    setBranches((prev) => prev.filter((b) => b.id !== id));
  }

  const value = { branches, addBranch, updateBranch, deleteBranch };
  return <BranchesContext.Provider value={value}>{children}</BranchesContext.Provider>;
}

export function useBranches() {
  return useContext(BranchesContext);
}
